from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📞 Поиск по номеру", callback_data="search_phone"),
            InlineKeyboardButton(text="✉️ Проверка email", callback_data="search_email"),
        ],
        [
            InlineKeyboardButton(text="👤 Поиск по никнейму", callback_data="search_username"),
            InlineKeyboardButton(text="🎯 Расширенные инструменты", callback_data="search_advanced"),
        ],
        [InlineKeyboardButton(text="🔍 Комплексная проверка", callback_data="search_full")],
    ])

def navigation(*, cancel: bool = True) -> InlineKeyboardMarkup:
    rows = []
    if cancel:
        rows.append([InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")])
    rows.append([InlineKeyboardButton(text="🏠 Главное меню", callback_data="home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def advanced_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌐 IP / домен", callback_data="advanced_domain")],
        [InlineKeyboardButton(text="🖼 Анализ EXIF-фото", callback_data="advanced_exif")],
        [InlineKeyboardButton(text="ℹ️ Возможности Telegram-профиля", callback_data="advanced_telegram")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="home")],
    ])
