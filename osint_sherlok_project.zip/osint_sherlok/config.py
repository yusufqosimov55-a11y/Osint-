import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    bot_token: str = os.getenv("BOT_TOKEN", "").strip()
    request_timeout: int = int(os.getenv("REQUEST_TIMEOUT", "25"))
    max_concurrent_jobs: int = int(os.getenv("MAX_CONCURRENT_JOBS", "2"))
    enable_maigret: bool = os.getenv("ENABLE_MAIGRET", "false").lower() == "true"
    maigret_command: str = os.getenv("MAIGRET_COMMAND", "maigret")
    enable_sherlock: bool = os.getenv("ENABLE_SHERLOCK", "false").lower() == "true"
    sherlock_command: str = os.getenv("SHERLOCK_COMMAND", "sherlock")

settings = Settings()
