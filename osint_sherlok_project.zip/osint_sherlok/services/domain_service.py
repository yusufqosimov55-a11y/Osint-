import ipaddress
import re
from urllib.parse import urlparse

def inspect_domain(value: str) -> str:
    value = value.strip()
    try:
        ip = ipaddress.ip_address(value)
        return (
            f"🌐 IP-адрес: <code>{ip}</code>\n"
            f"Тип: {'IPv4' if ip.version == 4 else 'IPv6'}\n"
            f"Глобально маршрутизируемый: {'да' if ip.is_global else 'нет'}\n"
            "Это локальная проверка формата и свойств IP; геолокация и сканирование сети не выполнялись."
        )
    except ValueError:
        pass
    candidate = value.lower().rstrip(".")
    if candidate.startswith("http://") or candidate.startswith("https://"):
        candidate = urlparse(candidate).hostname or ""
    if len(candidate) > 253 or not candidate or not re.fullmatch(
        r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", candidate
    ):
        return "❌ Не распознан IP-адрес или домен. Отправьте корректный IP или доменное имя."
    return (
        f"🌐 Домен: <code>{candidate}</code>\n"
        "Формат выглядит корректным. Внешний DNS/WHOIS-запрос в этой версии не выполнялся."
    )
