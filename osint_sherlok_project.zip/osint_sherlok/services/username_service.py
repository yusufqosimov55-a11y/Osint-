import asyncio
import shutil
from config import settings

async def _run_command(command: list[str], timeout: int) -> tuple[int, str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        output, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return proc.returncode or 0, output.decode("utf-8", errors="replace")[:12000]
    except asyncio.TimeoutError:
        try:
            proc.kill()
            await proc.wait()
        except Exception:
            pass
        return 124, "Время выполнения истекло."
    except FileNotFoundError:
        return 127, "Исполняемый файл не найден."

async def search_username(username: str) -> str:
    results = []
    ran = False

    if settings.enable_maigret:
        executable = shutil.which(settings.maigret_command)
        if executable:
            ran = True
            code, output = await _run_command(
                [executable, username, "--timeout", "10", "--no-progressbar"],
                settings.request_timeout,
            )
            results.append(f"<b>Maigret:</b> {'завершён' if code == 0 else 'ошибка/тайм-аут'}\n<pre>{_escape(output[-2500:])}</pre>")
        else:
            results.append("<b>Maigret:</b> включён в настройках, но команда не найдена.")

    if settings.enable_sherlock:
        executable = shutil.which(settings.sherlock_command)
        if executable:
            ran = True
            code, output = await _run_command(
                [executable, username, "--timeout", "10", "--print-found"],
                settings.request_timeout,
            )
            results.append(f"<b>Sherlock:</b> {'завершён' if code == 0 else 'ошибка/тайм-аут'}\n<pre>{_escape(output[-2500:])}</pre>")
        else:
            results.append("<b>Sherlock:</b> включён в настройках, но команда не найдена.")

    if not ran:
        return (
            "Maigret/Sherlock: <b>не подключены</b>.\n"
            "Установите нужный инструмент и явно включите его в переменных окружения. "
            "Никакой поиск в этой сборке не выполнялся."
        )
    return "\n\n".join(results) + "\n\nИнструменты могут выдавать ложные совпадения; проверяйте профили вручную."

def _escape(value: str) -> str:
    return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
