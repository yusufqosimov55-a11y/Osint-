import phonenumbers
from phonenumbers import geocoder, carrier

def inspect_phone(value: str) -> str:
    try:
        parsed = phonenumbers.parse(value, None)
    except phonenumbers.NumberParseException:
        return "❌ Не удалось распознать номер. Используйте международный формат, например +998901234567."
    if not phonenumbers.is_possible_number(parsed):
        return "❌ Номер имеет неподходящую длину или формат."
    valid = phonenumbers.is_valid_number(parsed)
    region = geocoder.description_for_number(parsed, "ru") or "не определён"
    operator = carrier.name_for_number(parsed, "ru") or "не определён"
    return (
        f"Формат: {'корректный' if valid else 'возможный, но не подтверждён как действующий'}\n"
        f"Страна/регион: {region}\n"
        f"Оператор: {operator or 'не определён'}\n\n"
        "Важно: эти сведения вычисляются по нумерационным данным и не устанавливают владельца номера."
    )
