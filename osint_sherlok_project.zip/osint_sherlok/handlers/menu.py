from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery

from keyboards import main_menu, advanced_menu

router = Router()

WELCOME = (
    "🕵️‍♂️ <b>OSINT SHERLOK</b>\n"
    "<i>Инструменты поиска по открытым источникам</i>\n\n"
    "Добро пожаловать! Выберите тип проверки, чтобы начать работу.\n\n"
    "⚠️ Результаты зависят от доступности публичных источников. "
    "Бот не гарантирует обнаружение всех данных и не предоставляет доступ к закрытой информации."
)

@router.message(CommandStart())
async def start(message: Message):
    await message.answer(WELCOME, reply_markup=main_menu())

@router.message(Command("help"))
async def help_command(message: Message):
    await message.answer(
        "Выберите направление в меню. Используйте только данные, которые вправе проверять. "
        "Бот не получает доступ к закрытым аккаунтам, переписке или паролям.",
        reply_markup=main_menu(),
    )

@router.callback_query(F.data == "home")
async def home(callback: CallbackQuery):
    await callback.answer()
    await callback.message.edit_text(WELCOME, reply_markup=main_menu())

@router.callback_query(F.data == "search_advanced")
async def advanced(callback: CallbackQuery):
    await callback.answer()
    await callback.message.edit_text(
        "🎯 <b>Расширенные инструменты</b>\n\n"
        "Выберите действие. Некоторые функции требуют дополнительной настройки.",
        reply_markup=advanced_menu(),
    )
