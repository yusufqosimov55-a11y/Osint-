import asyncio
import ipaddress
import re
import time
from urllib.parse import urlparse

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from keyboards import navigation, main_menu, advanced_menu
from services.phone_service import inspect_phone
from services.email_service import validate_email
from services.username_service import search_username
from services.domain_service import inspect_domain

router = Router()
JOB_SEMAPHORE = asyncio.Semaphore(2)

class SearchFlow(StatesGroup):
    phone = State()
    email = State()
    username = State()
    full = State()
    domain = State()
    exif = State()
    telegram = State()

PROMPTS = {
    "search_phone": ("📞 Отправьте номер телефона в международном формате, например +998901234567.", SearchFlow.phone),
    "search_email": ("✉️ Отправьте email-адрес для проверки формата. Проверка не раскрывает закрытые данные аккаунтов.", SearchFlow.email),
    "search_username": ("👤 Отправьте никнейм без пробелов. Будут проверяться только публичные профили, если модуль поиска настроен.", SearchFlow.username),
    "search_full": ("🔍 Отправьте номер, email или никнейм. Бот определит формат и запустит только совместимые доступные проверки.", SearchFlow.full),
}

@router.callback_query(F.data.in_(list(PROMPTS.keys())))
async def choose_search(callback: CallbackQuery, state: FSMContext):
    prompt, flow_state = PROMPTS[callback.data]
    await state.set_state(flow_state)
    await callback.answer()
    await callback.message.edit_text(prompt, reply_markup=navigation())

@router.callback_query(F.data == "cancel")
async def cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.answer("Поиск отменён")
    await callback.message.edit_text("Действие отменено. Выберите следующий пункт:", reply_markup=main_menu())

@router.callback_query(F.data == "advanced_domain")
async def ask_domain(callback: CallbackQuery, state: FSMContext):
    await state.set_state(SearchFlow.domain)
    await callback.answer()
    await callback.message.edit_text("🌐 Отправьте домен или IP-адрес для базовой публичной проверки.", reply_markup=navigation())

@router.callback_query(F.data == "advanced_exif")
async def ask_exif(callback: CallbackQuery, state: FSMContext):
    await state.set_state(SearchFlow.exif)
    await callback.answer()
    await callback.message.edit_text("🖼 Отправьте фотографию как документ или фото. Бот проверит наличие EXIF-метаданных; геолокация может отсутствовать.", reply_markup=navigation())

@router.callback_query(F.data == "advanced_telegram")
async def ask_telegram(callback: CallbackQuery, state: FSMContext):
    await state.set_state(SearchFlow.telegram)
    await callback.answer()
    await callback.message.edit_text(
        "ℹ️ Telegram показывает только ограниченные сведения, доступные через сам Telegram. "
        "Отправьте публичный @username для справки о возможностях и ограничениях; бот не может искать скрытые данные.",
        reply_markup=navigation(),
    )

@router.message(StateFilter(SearchFlow.phone))
async def phone_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()
    if len(value) > 40:
        await message.answer("Слишком длинный ввод. Отправьте номер телефона ещё раз.", reply_markup=navigation())
        return
    await run_and_reply(message, state, "Телефон", inspect_phone(value))

@router.message(StateFilter(SearchFlow.email))
async def email_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()
    if len(value) > 254:
        await message.answer("Email слишком длинный.", reply_markup=navigation())
        return
    await run_and_reply(message, state, "Email", validate_email(value))

@router.message(StateFilter(SearchFlow.username))
async def username_input(message: Message, state: FSMContext):
    value = (message.text or "").strip().lstrip("@")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", value):
        await message.answer("Никнейм должен содержать только латинские буквы, цифры, точку, дефис или подчёркивание.", reply_markup=navigation())
        return
    async with JOB_SEMAPHORE:
        await message.bot.send_chat_action(message.chat.id, "typing")
        status = await message.answer("⏳ Проверяю доступные модули…")
        start = time.monotonic()
        result = await search_username(value)
        await status.edit_text(
            f"🕵️ <b>Результаты OSINT SHERLOK</b>\n\n"
            f"Тип проверки: никнейм\n"
            f"{result}\n\n"
            f"Время: {time.monotonic() - start:.1f} сек.\n"
            "⚠️ Результат может быть неполным и сам по себе не подтверждает личность владельца.",
            reply_markup=navigation(),
        )
    await state.clear()

@router.message(StateFilter(SearchFlow.full))
async def full_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()
    if len(value) > 254:
        await message.answer("Ввод слишком длинный.", reply_markup=navigation())
        return
    if "@" in value and "." in value and not value.startswith("@"):
        result = validate_email(value)
        kind = "email"
    elif re.fullmatch(r"\+?[0-9()\- .]{7,30}", value):
        result = inspect_phone(value)
        kind = "номер телефона"
    elif re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", value.lstrip("@")):
        kind = "никнейм"
        result = await search_username(value.lstrip("@"))
    else:
        await message.answer("Не удалось определить тип данных. Отправьте номер, email или никнейм.", reply_markup=navigation())
        return
    await message.answer(
        f"🔍 <b>Комплексная проверка</b>\n\nТип данных: {kind}\n{result}\n\n"
        "⚠️ Запущены только совместимые доступные проверки. Результаты могут быть неполными.",
        reply_markup=navigation(),
    )
    await state.clear()

@router.message(StateFilter(SearchFlow.domain))
async def domain_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()
    result = inspect_domain(value)
    await message.answer(result, reply_markup=navigation())
    await state.clear()

@router.message(StateFilter(SearchFlow.telegram))
async def telegram_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()
    if not re.fullmatch(r"@?[A-Za-z0-9_]{5,32}", value):
        await message.answer("Введите публичный @username в допустимом формате.", reply_markup=navigation())
        return
    await message.answer(
        f"ℹ️ Получен username <code>{value.lstrip('@')}</code>.\n"
        "Этот бот не извлекает скрытые сведения. Доступность имени и публичные данные зависят от настроек Telegram.",
        reply_markup=navigation(),
    )
    await state.clear()

@router.message(StateFilter(SearchFlow.exif), F.photo | F.document)
async def exif_file(message: Message, state: FSMContext):
    await message.answer(
        "Функция EXIF-анализа пока не подключена. Файл не сохранялся и не анализировался. "
        "Интеграцию можно добавить отдельным модулем с лимитом размера и удалением временных файлов.",
        reply_markup=navigation(),
    )
    await state.clear()

@router.message(StateFilter(SearchFlow.exif))
async def exif_wrong_input(message: Message):
    await message.answer("Пожалуйста, отправьте изображение или нажмите «Отмена».", reply_markup=navigation())

async def run_and_reply(message: Message, state: FSMContext, kind: str, result: str):
    await message.answer(f"✅ <b>{kind}</b>\n\n{result}", reply_markup=navigation())
    await state.clear()
